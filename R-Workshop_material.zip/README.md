# R_Geo_workshop
Programming with R – A Beginners’ Guide for Geoscientists
